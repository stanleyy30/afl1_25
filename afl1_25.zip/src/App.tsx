import Post from "./components/Post";

const App = () => {
  return (
    <div>
      <Post />
    </div>
  );
};

export default App;
