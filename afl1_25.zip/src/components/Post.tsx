// ... other imports
import Money from "../assets/icons/money-management.png";
import { useState, useEffect } from "react";

const Post = () => {
  const [money, setMoney] = useState(0);
  const [increment, setIncrement] = useState(1);
  const [temporaryIncrement, setTemporaryIncrement] = useState(increment); // New state for temporary increment
  const [shopItems, setShopItems] = useState([
    {
      id: 1,
      name: "Upgrade",
      cost: 100,
      unlocked: true,
      onPurchase: () => {
        setIncrement((prev) => prev + 1);
      },
    },
    {
      id: 2,
      name: "Super Upgrade",
      cost: 2000,
      unlocked: true,
      onPurchase: () => {
        setIncrement((prev) => prev * 10);
      },
    },
  ]);
  
  const [upgradeCount, setUpgradeCount] = useState(0);
  const [isMoneyRainActive, setIsMoneyRainActive] = useState(false);
  const [rainDuration, setRainDuration] = useState(0);
  const [pendingUpgrades, setPendingUpgrades] = useState(0); // Track pending upgrades

  const handleClick = () => {
    const currentIncrement = isMoneyRainActive ? temporaryIncrement : increment; // Use temporary increment during Money Rain
    setMoney((prevScore) => prevScore + currentIncrement);
  };

  const handlePurchase = (itemId) => {
    const item = shopItems.find((item) => item.id === itemId);
    if (item && money >= item.cost) {
      setMoney(money - item.cost);
  
      // Apply the upgrade immediately
      if (itemId === 1) {
        setIncrement((prev) => prev + 1); // Directly increase the increment by 1
        setPendingUpgrades((prev) => prev + 1); // Track the upgrade
      } else {
        item.onPurchase(); // For other upgrades, call their onPurchase method
      }
      
      setUpgradeCount((prevCount) => prevCount + 1);
  
      setShopItems((prevItems) =>
        prevItems.map((prevItem) => {
          if (prevItem.id === itemId) {
            if (prevItem.id === 1) {
              return { ...prevItem, cost: prevItem.cost * 2 }; // Double cost after purchase
            } else if (prevItem.id === 2) {
              return { ...prevItem, cost: prevItem.cost * 100 };
            }
          }
          return prevItem;
        })
      );
  
      // Activate Money Rain after 3 upgrades
      if (upgradeCount + 1 === 3 && !isMoneyRainActive) {
        activateMoneyRain();
      }
    }
  };
  const activateMoneyRain = () => {
    setIsMoneyRainActive(true);
    setTemporaryIncrement(increment * 2); // Double the increment during Money Rain
    setRainDuration(60); // 1 minute in seconds
  };

  useEffect(() => {
    let timer;
    if (isMoneyRainActive && rainDuration > 0) {
      timer = setInterval(() => {
        setRainDuration((prev) => prev - 1);
      }, 1000);
    } else if (rainDuration === 0) {
      setIsMoneyRainActive(false);
      setTemporaryIncrement(increment); // Revert back to original increment
      applyPendingUpgrades(); // Apply upgrades after Money Rain ends
    }

    return () => clearInterval(timer);
  }, [isMoneyRainActive, rainDuration, increment]);

  const applyPendingUpgrades = () => {
    setIncrement((prev) => prev + pendingUpgrades); // Apply all pending upgrades
    setPendingUpgrades(0); // Reset pending upgrades
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-green-100 relative">
      {/* Shop section */}
      <div className="absolute top-0 right-0 m-4">
        <div className="bg-blue-600 text-white p-4 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-2">Shop</h2>
          {isMoneyRainActive ? (
            <p className="text-yellow-500 font-bold mb-2">Money Rain is active! Double money for 1 minute!</p>
          ) : (
            <p className="text-red-500 font-bold mb-2">Money Rain is inactive.</p>
          )}
          <ul className="space-y-2">
            {shopItems.map((item) => (
              <li key={item.id} className="flex justify-between items-center bg-blue-500 p-2 rounded mb-1">
                <span>{item.name} (Cost: {item.cost})</span>
                <button
                  onClick={() => handlePurchase(item.id)}
                  className={`px-2 py-1 ml-2 text-white font-bold rounded ${
                    money >= item.cost
                      ? "bg-green-500 hover:bg-green-700"
                      : "bg-gray-400 cursor-not-allowed"
                  }`}
                  disabled={money < item.cost}
                >
                  Buy
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Main content */}
      <h1 className="text-4xl font-bold mb-4">Money Clicker Game!</h1>
      <p className="text-2xl font-semibold mb-4">Money: ${money}</p>
      <p className="text-xl font-semibold mb-4">Current Income: +{temporaryIncrement}</p> {/* Show temporary increment */}
      <p className="text-xl font-semibold mb-4">Click the Money to get Money</p>
      <img
        src={Money}
        alt="Money"
        className="w-64 h-64 cursor-pointer transition transform hover:scale-105"
        onClick={handleClick}
      />
    </div>
  );
};

export default Post;